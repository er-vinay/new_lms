   <footer>
            <div class="container">
                <div class="row">
                    <div class="col-md-9">
                        <div class="footer-content">
                            <h2>ABOUT</h2>
                            <p>Naman Finlease Pvt Ltd. is a NBFC registered with RBI having its registered office at S-370, Panchsheel Park, New Delhi – 110 017. The company uses proprietary loan softwares for its various loan offerings to individual customers in a completely fintech environment.</p>
                        </div>
                    </div>
                    
                    <div class="col-md-3">
                        <div class="footer-support">
                            <h2>CONTACT SUPPORT</h2>
                            <p><i class="fa fa-envelope"></i>&nbsp;<a href="mailto:vinay.kumar@loanwalle.com">vinay.kumar@loanwalle.com</a></p>
                            <p><i class="fa fa-phone"></i>&nbsp;<a href="tel:+918936962573">+91 89369 62573</a></p> 
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
        <script>
        $(document).ready(function(){
        $(".togglebtn").click(function(){
        $(".shome").toggle("fast");
        });
        });
        </script>
        <script src="<?= base_url(); ?>public/js/jquery-1.11.2.min.js"></script>
        <!-- <script src="<?= base_url(); ?>public/js/jquery-migrate-1.2.1.min.js"></script> -->
        <script src="<?= base_url(); ?>public/js/jRespond.min.js"></script>
        <script src="<?= base_url(); ?>public/js/nav-accordion.js"></script>
        <script src="<?= base_url(); ?>public/js/hoverintent.js"></script>
        <script src="<?= base_url(); ?>public/js/waves.js"></script>
        <script src="<?= base_url(); ?>public/js/switchery.js"></script>
        <script src="<?= base_url(); ?>public/js/jquery.loadmask.js"></script>
        <script src="<?= base_url(); ?>public/js/icheck.js"></script>
        <script src="<?= base_url(); ?>public/js/bootstrap-filestyle.js"></script>
        <script src="<?= base_url(); ?>public/js/bootbox.js"></script>
        <script src="<?= base_url(); ?>public/js/animation.js"></script>
        <script src="<?= base_url(); ?>public/js/colorpicker.js"></script>
        <script src="<?= base_url(); ?>public/js/bootstrap-datepicker.js"></script>
        <script src="<?= base_url(); ?>public/js/sweetalert.js"></script>
        <script src="<?= base_url(); ?>public/js/moment.js"></script>
        <script src="<?= base_url(); ?>public/js/summernote.min.js"></script>
        <script src="<?= base_url(); ?>public/js/calendar/fullcalendar.js"></script>
        
        <script src="<?= base_url(); ?>public/js/smart-resize.js"></script>
        <script src="<?= base_url(); ?>public/js/layout.init.js"></script>
        <script src="<?= base_url(); ?>public/js/matmix.init.js"></script>
        <script src="<?= base_url(); ?>public/js/retina.min.js"></script>


        
        <script src="<?= base_url(); ?>public/front/js/dataTable/dataTable_1.10.25.min.js"></script>
        <script src="<?= base_url(); ?>public/front/js/dataTable/dataTable.semantic.min.js"></script>
        
        <script src="<?= base_url(); ?>public/js/jquery.dataTables.js"></script>
        <script src="<?= base_url(); ?>public/js/dataTables.tableTools.js"></script>
        <script src="<?= base_url(); ?>public/js/dataTables.bootstrap.js"></script>
        <script src="<?= base_url(); ?>public/js/bootstrap.min.js"></script>
        <script src="<?= base_url(); ?>public/js/dataTables.responsive.js"></script> 
        <script src="<?= base_url(); ?>public/js/stacktable.js"></script>
        <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.11/summernote.js"></script> -->
        <!-- <script src="//cdnjs.cloudflare.com/ajax/libs/summernote/0.8.7/summernote.js"></script> -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
        <script src="<?= base_url(); ?>public/front/js/datepicker.min.js"></script>
        <script src="<?= base_url(); ?>public/front/js/jquery.multiselect.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
        <script src="<?= base_url(); ?>public/front/js/ace-responsive-menu.js"></script>
        <script src="<?= base_url(); ?>public/front/js/price-counter/jquery.countup.js"></script>

        
         <script type="text/javascript">
            loader();
            function loader(){
                $(window).on('load', function () {
                    $("#cover").fadeOut(1750);
                });
            }
            $(document).ready(function () {
                $(window).on('load', function () {
                    $("#cover").fadeOut(1750);
                });
                 $("#respMenu").aceResponsiveMenu({
                     resizeWidth: '768', // Set the same in Media query
                     animationSpeed: 'fast', //slow, medium, fast
                     accoridonExpAll: false //Expands all the accordion menu on click
                 });
             
                $('.counter').each(function(){
                    $(this).prop('Counter',0).animate({
                        Counter: $(this).text()
                    },{
                      duration: 3500,
                      easing: 'swing',
                      step: function (now){
                          $(this).text(Math.ceil(now));
                      }
                    });
                });
            });
        </script>
        <!--counter end-->
        <script type="text/javascript">
            var fullDate = new Date();
            var currentMonth = ((fullDate.getMonth().length+1) === 1) ? (fullDate.getMonth()+1) : '0' + (fullDate.getMonth()+1);
            var fullDate =  fullDate.getFullYear() + "-" + currentMonth + "-" + fullDate.getDate();
            // var valid_age =  fullDate.getFullYear() - 20 + "-" + currentMonth + "-" + fullDate.getDate();
            // var valid_start_age =  fullDate.getFullYear() - 60 + "-" + currentMonth + "-" + fullDate.getDate();
            // console.log("currentMonth : " +currentMonth);

            $(document).ready(function() {
                 $("#dob, DOB, #dateOfJoining, #date_of_recived, #dob").keypress(function myfunction(event) {
                    var regex = new RegExp("^[0-9?=.*!@#$%^&*]+$");               
                    var key = String.fromCharCode(event.charCode ? event.which : event.charCode);
                     if (!regex.test(key)) {
                        event.preventDefault();
                        return false;
                    }              
                    return false; 
                });
                $("#dob, #dateOfJoining, #date_of_recived").datepicker({
                    format: 'yyyy-mm-dd',
                    todayHighlight: true,
                    autoclose: true,
                    // startView: 2,
                    endDate : new Date(),
                });
                
                $("#DOB").datepicker({
                    format: 'dd-mm-yyyy',
                    todayHighlight: true,
                    autoclose: true,
                    // startView: 2,
                    startDate: '-60y',
                    endDate: '-19y'
                });

                $("#cc_statementDate").datepicker({
                    format: 'dd-mm-yyyy',
                    todayHighlight: true,
                    autoclose: true,
                    startDate: '-30d',
                    endDate: new Date()
                });

                $("#cc_paymentDueDate, #repayment_date, #repayment_date").datepicker({
                    format: 'dd-mm-yyyy',
                    todayHighlight: true,
                    autoclose: true,
                    startDate: new Date(),
                    endDate: '+30d'
                });
                
                $("#disbursal_date").datepicker({
                    format: 'dd-mm-yyyy',
                    todayHighlight: true,
                    autoclose: true,
                    startDate: new Date(),
                    endDate: '+30d'
                });
            });
            
            $("#fromDate, .SearchForExport").prop('disabled', true);
            $("#toDate").datepicker({
                format: 'dd-mm-yyyy',
                todayHighlight: true,
                autoclose: true,
                // startView: 2,
                endDate : Date(),
            });
        
            $("#toDate").change(function(){
                var todate = $(this).val();
                $("#fromDate").prop('disabled', false);
                $("#fromDate").datepicker({
                    format: 'yyyy-mm-dd',
                    todayHighlight: true,
                    autoclose: true,
                    // startView: 2,
                    startDate : todate,
                    endDate : Date(),
                });
            });
        </script>
        
        <script>
            
            $(document).ready(function() {
                $("#mobile, #alternateMobileNo").keypress(function (e) {
                    $('#errormobile').html('');
                    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                        $('#errormobile').html('Number Only!').show().css({'color' : 'red'}).fadeOut('slow');
                       return false;
                    }
                    if($(this).val().length >=10){
                        $('#errormobile').html('Verified Mobile!').show().css({'color' : 'green'});
                       return false;
                    }
                    if($(this).val().length < 9)
                    {
                        $('#errormobile').html('Mobile 10 digit required!').show().css({'color' : 'red'});
                    }else{
                        $('#errormobile').html('Verified Mobile!').show().css({'color' : 'green'});

                    }
                });

                $("#pincode, #yourPincode").keypress(function (e) {
                    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                       return false;
                    }
                    if($(this).val().length >=6){
                       return false;
                    }
                    if($(this).val().length < 5)
                    {
                        $('#errorpincode').html('Pincode 6 digit required!').show().css({'color' : 'red'});
                    }else{
                        $('#errorpincode').html('Verified Pincode!').show().css({'color' : 'green'});

                    }
                });

                // number only

                $("#higherDPDLast3month, #loan_recomended, #processing_fee, #cc_outstanding, #cc_limit").keypress(function (e) {
                    if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
                       return false;
                    }
                });
                $("#roi").keypress(function (e) {
                    var val = $j(this).val();
                    var regex = /^(\+|-)?(\d*\.?\d*)$/;
                    if (regex.test(val + String.fromCharCode(e.charCode))) {
                        return true;
                    }
                    return false;
                });

                // alpha only

                $('#borrower_name, #gender, #pancard, #state, #city, #special_approval, #customer_name, #bankHolder_name').keyup(function(){
                    $(this).val($(this).val().toUpperCase());
                }); 

                $("#name, #firstName, #lastName, #customer_name, #special_approval, #bankHolder_name").keypress(function(event){
                    var inputValue = event.which;
                    if(!(inputValue >= 65 && inputValue <= 122) && (inputValue != 32 && inputValue != 0)) { 
                        event.preventDefault(); 
                    }
                });

            });
            function IsEmail(email) {
                var regex = /([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})/;
                let valid_email = $(email).val();
                if (valid_email.match(regex)) {
                    return true;
                }
                else {
                    $(email).val("").focus();
                    return false;
                }
            }
            
            function IsOfficialEmail(email) 
            {
                let valid_email = $(email).val();
                // var re = /.+@(gmail|loanwalle)\.com$/;
                var re = /.+@(loanwalle)\.com$/;
                var validEmail = re.test(valid_email);
                if(validEmail == true){
                    $("#emailErr").html("");
                    return true;
                }else{
                    $(email).val("");
                    $("#emailErr").html("Acceptable domain name '@loanwalle.com'").css('color', 'red');
                    return false;
                }
            }
            
            function validatePanNumber(pan) 
            {
                let pannumber = $(pan).val();
                var regex = /[a-zA-z]{5}\d{4}[a-zA-Z]{1}/;
                if (pannumber.length == 10 ) { 
                    if (pannumber.match(regex)) {
                        $(pan).css('border-color', 'lightgray');
                    }
                    else {
                        $(pan).val("").focus().css('border-color', 'red');
                        return false;
                    }
                }else{
                    $(pan).val("").focus().css('border-color', 'red');
                    return false;
                }
            }
            
        </script>
        <script src="<?= base_url(); ?>public/js/toast_notification/flash.min.js"></script>
        <script type="text/javascript">
            function catchSuccess(success){ 
                $('<audio id="chatAudio"><source src="https://fintechcloud.in/lac/public/ringtone/success.mp3" type="audio/ogg"><source src="https://fintechcloud.in/lac/public/ringtone/success.mp3" type="audio/mpeg"></audio>').appendTo('body');
                $('#chatAudio')[0].play();
                flash(success, {'bgColor' : '#2d6f36'})
            }
            function catchError(error){
                $('<audio id="chatAudio"><source src="https://fintechcloud.in/lac/public/ringtone/success.mp3" type="audio/ogg"><source src="https://fintechcloud.in/lac/public/ringtone/success.mp3" type="audio/mpeg"></audio>').appendTo('body');
                $('#chatAudio')[0].play();
                flash(error, {'bgColor' : '#C0392B'})
            }
            function catchNotification(notify){
                $('<audio id="chatAudio"><source src="https://fintechcloud.in/lac/public/ringtone/success.mp3" type="audio/ogg"><source src="https://fintechcloud.in/lac/public/ringtone/success.mp3" type="audio/mpeg"></audio>').appendTo('body');
                $('#chatAudio')[0].play();
                flash(notify, {'bgColor' : '#d4ac1a'})
            }
            
            var _gaq = _gaq || [];
            _gaq.push(['_setAccount', 'UA-36251023-1']);
            _gaq.push(['_setDomainName', 'jqueryscript.net']);
            _gaq.push(['_trackPageview']);
            
            (function() {
            var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
            })();
        </script>
    </body>
</html>
